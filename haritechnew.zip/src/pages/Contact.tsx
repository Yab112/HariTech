import ContactForm from "@/components/contact-form";
import DualTitle from "@/components/dual-title";
import Footer from "@/components/footer";

const ContactPage = () => {
  return (
    <>
      <section className="w-full bg-[#F0F3F5] py-20 md:py-24">
        <div className="container mx-auto px-4">
          <DualTitle
            firstTitle="Contact"
            secondTitle="Us"
            subtitle="Helping tradies and businesses streamline operations with intuitive technology."
          />
          <ContactForm />
        </div>
      </section>
        <Footer bgColor="bg-[#F0F3F5]" />
  
    </>
  );
};

export default ContactPage;
