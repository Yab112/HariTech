import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import DualTitle from "../dual-title";

export default function FeatureSection() {
  return (
    <section className="w-full bg-[#F0F3F5] py-8 md:py-10">
      <DualTitle
        firstTitle="Simple Tools,"
        secondTitle="Real Results"
        subtitle="From admin support to workforce training — Grow2 builds tech that keeps tradies and businesses moving forward."
      />
      <div className="container mx-auto px-4 max-md:mt-10  ">
        <div className="grid gap-6 md:grid-cols-3 lg:gap-8">
          {/* Time Saving Card */}
          <div className="rounded-lg bg-background  pb-6 shadow-sm text-white relative  flex flex-col items-center">
            <div className=" absolute -top-12 left-3 ">
              <img src="/feature-chart.svg" alt="" />
            </div>
            <div className=" h-72 w-full"></div>
            <h3 className="mb-2 text-xl font-semibold text-center ">
              30% Less Time Chasing Info
            </h3>
            <p className="text-sm  text-center max-w-[300px]">
              Tradies and office staff save hours collecting timesheets,
              reports, and job details — AdminOh does the running around.
            </p>
          </div>

          <div className="rounded-lg bg-white px-2 shadow-sm flex flex-col items-center pb-6">
            <div className="h-72 w-full b">
              <div className=" h-56 w-full pt-6">
                <RatingDisplay />
              </div>
            </div>
            <h3 className="mb-2 text-center text-xl font-semibold text-black ">
              Boost Reviews. Build Trust.
            </h3>
            <p className="text-center text-sm text-gray-600 max-w-[300px]">
              AdminOh helps you collect customer feedback. UTRADIE turns that
              into social proof to grow your business reputation.
            </p>
          </div>

          {/* Time Savings Card */}
          <div className="rounded-lg bg-white shadow-sm  flex flex-col items-center pb-6">
            <div className="h-72 w-full  p-6">
              <div className=" h-56 flex justify-center w-full">
                <img
                  src="/time.svg"
                  alt=""
                  className=" object-contain h-full"
                />
              </div>
            </div>
            <h3 className="mb-2 text-center text-xl font-semibold text-black">
              32 Minutes Instead of 3 Hours
            </h3>
            <p className="text-center text-sm text-gray-600 max-w-[300px]">
              That's how fast our helpers can knock over tasks like feedback
              collection, file sorting, or daily logs. Admin done, no stress.
            </p>
          </div>
        </div>

        <div className="mt-10 flex justify-center">
          <Link
            to="/product"
            className="inline-flex w-full justify-center md:w-fit items-center rounded-full bg-primary px-6 py-3 text-sm font-medium text-white transition-colors hover:bg-primary/90"
          >
            Our Products
            <ArrowUpRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}

function RatingDisplay() {
  return (
    <div className="flex h-full w-full gap-6 relative  items-center justify-center rounded-3xl bg-primary p-4 text-white">
      <div className="flex flex-col flex-[1]">
        <div className="mb-2 flex items-center">
          <span className="text-4xl font-bold">4.5</span>
          <span className="ml-2 text-2xl text-yellow-400">★</span>
        </div>
        <div className="mb-3 rounded-full bg-white px-3 py-1 text-xs text-gray-800">
          653 reviews
        </div>
      </div>

      <div className="mb-4 w-full space-y-1 flex-[2] ">
        {[5, 4, 3, 2, 1].map((rating) => (
          <div key={rating} className="flex items-center">
            <span className="mr-2 w-3 text-sm">{rating}</span>
            <div
              className="h-2 rounded-full bg-green-400"
              style={{
                width: `${
                  rating === 5
                    ? "100%"
                    : rating === 4
                    ? "85%"
                    : rating === 3
                    ? "60%"
                    : rating === 2
                    ? "40%"
                    : "20%"
                }`,
              }}
            ></div>
          </div>
        ))}
      </div>
      <div className=" flex absolute -bottom-4 right-10">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="relative -mr-2 h-10 w-10 overflow-hidden rounded-full border-2 border-white"
            style={{ zIndex: 5 - i }}
          >
            <div className="h-full w-full bg-gray-300"></div>
          </div>
        ))}
        <div className="relative -mr-2 flex h-10 w-10 items-center justify-center rounded-full border-2 border-white bg-green-500 text-xs font-medium text-white">
          15K
        </div>
      </div>
    </div>
  );
}

function TimerDisplay() {
  return (
    <div className="flex h-full w-full items-center justify-center text-black">
      <div className="relative h-40 w-40">
        {/* Background circle */}
        <svg className="h-full w-full" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="#f1f1f1"
            strokeWidth="8"
          />
          {/* Progress circle - approximately 75% complete */}
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="#0a3049"
            strokeWidth="8"
            strokeDasharray="283"
            strokeDashoffset="70"
            transform="rotate(-90 50 50)"
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-4xl font-bold">32:10</span>
        </div>
      </div>
    </div>
  );
}
