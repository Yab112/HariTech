import { useState } from "react";
import { Minus, Plus } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import DualTitle from "../dual-title";

// FAQ data structure
const faqItems = [
  {
    question: "What's the difference between UTRADIE and AdminOh?",
    answer:
      "UTRADIE helps you train your crew, onboard new hires, and keep your team on the same page. AdminOh is where you hand off those annoying admin tasks to real people who just get it done — no bots, no drama.",
  },
  {
    question: "What kind of admin jobs can AdminOh help with?",
    answer:
      "AdminOh can help with a wide range of administrative tasks including data entry, scheduling, email management, customer support, research, and more. Our team handles the day-to-day admin work so you can focus on growing your business.",
  },
  {
    question: "Can I use UTRADIE and AdminOh together?",
    answer:
      "Many of our clients use both platforms for maximum efficiency. UTRADIE helps you manage your internal team and training, while AdminOh handles your administrative workload. They're designed to complement each other perfectly.",
  },
  {
    question: "Do I need to be tech-savvy to use these platforms?",
    answer:
      "Not at all. Both platforms are designed with user-friendliness in mind. They feature intuitive interfaces that require no technical expertise. Plus, our support team is always available to help you get started and answer any questions.",
  },
  {
    question: "What are credits, and how do they work with AdminOh?",
    answer:
      "You buy credits based on how much help you want. Each task costs a few credits, depending on size. No contracts, no hidden fees — just pay for what you use.",
  },
  {
    question: "How do I post a task with AdminOh?",
    answer:
      "Posting a task is simple. Just log into your AdminOh dashboard, click 'New Task', fill in the details of what you need done, set any deadlines, and submit. One of our qualified admins will be assigned to your task promptly.",
  },
  {
    question: "Can I create training content in UTRADIE myself?",
    answer:
      "Yes, UTRADIE provides an easy-to-use content creation tool that allows you to build custom training materials. You can upload videos, create quizzes, add documents, and organize everything into structured courses for your team.",
  },
  {
    question: "How fast do tasks get done?",
    answer:
      "Task completion times vary depending on complexity, but most standard tasks are completed within 24-48 hours. For urgent requests, we offer priority processing that can deliver results in as little as a few hours.",
  },
];

export default function FAQSection() {
  const [openItems, setOpenItems] = useState<string[]>([]);

  return (
    <section id="faq" className="w-full bg-white py-8 md:py-10">
      <div className=" container mx-auto px-4">
        {/* <div className="text-center mb-12 px-4">
          <h2 className="text-4xl font-bold mb-2 relative inline-block">
           
            <span className="absolute bottom-0 left-0 w-full h-1 bg-emerald-500"></span>
          </h2>
          <p className="text-gray-600 mt-4">
          
          </p>
        </div> */}
        <DualTitle
          firstTitle="Let's Clear a"
          secondTitle="Few Things Up"
          subtitle="No fluff. No jargon. Just straight-up answers to what everyone's
            thinking."
        />

        <div className="grid md:grid-cols-2 md:gap-6 gap-4">
          {faqItems.map((item, index) => (
            <div key={index} className="border rounded-lg overflow-hidden">
              <Accordion
                type="multiple"
                value={openItems}
                onValueChange={(value) => {
                  setOpenItems(value);
                }}
                className="w-full"
              >
                <AccordionItem value={`item-${index}`} className="border-0">
                  <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-gray-50 group">
                    <div className="flex items-center">
                      <div className="mr-4 flex-shrink-0">
                        {openItems.includes(`item-${index}`) ? (
                          <Minus className="h-5 w-5 text-emerald-500" />
                        ) : (
                          <Plus className="h-5 w-5 text-gray-400" />
                        )}
                      </div>
                      <span className="text-left max-md:text-sm font-medium text-gray-800">
                        {item.question}
                      </span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-4 pt-0 text-gray-600">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
