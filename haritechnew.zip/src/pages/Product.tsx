import Footer from "@/components/footer";
import ProductHeroSection from "@/components/product/product-hero";
import Showcase from "@/components/product/showcase";

const ProductPage = () => {
  return (
    <div>
      <ProductHeroSection />
      <Showcase />
      <Footer bgColor="bg-[#F0F3F5]" />
    </div>
  );
};

export default ProductPage;
