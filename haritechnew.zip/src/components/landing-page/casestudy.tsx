import DualTitle from "../dual-title";
import { ProductShowcase } from "../product-showcase";

const CaseStudy = () => {
  return (
    <section className="w-full bg-[#F0F3F5] py-8 md:py-10">
      <div className=" container mx-auto">
        <DualTitle
          firstTitle="Our"
          secondTitle="Products"
          subtitle="Helping tradies and businesses streamline operations with intuitive technology."
        />
        <div className="flex flex-col gap-6 items-center justify-between">
          <ProductShowcase
            subtitle="UTRADIE"
            title="Our Core Product For"
            highlightedText="Tradies & Growing Teams."
            description="UTRADIE helps you train, brief, and grow your team with confidence. Build learning cards, track progress, and share knowledge across your crew — all in one place."
            imageSrc="/uthradie-pc.png?height=600&width=800"
            imageAlt="Utradie dashboard on laptop"
            primaryButtonText="View Website"
            primaryButtonUrl="https://utradie.com"
            secondaryButtonText="Case Study"
            secondaryButtonUrl="#"
            accentColor="#10b981"
          />
          <ProductShowcase
            subtitle="AdminOh"
            title="Flexible Admin Support For Busy"
            highlightedText="Tradies & Business Owners."
            description="AdminOh gives you a team of helpers on demand — just post your task and we'll handle the admin. From collecting feedback to chasing files or posting on socials, your time-wasting jobs are finally off your plate."
            imageSrc="/adminoh.png"
            imageAlt="AdminOh platform on laptop showing a cartoon character and text about revolutionizing trade businesses"
            primaryButtonText="View Website"
            primaryButtonUrl="http://www.adminoh.com/"
            secondaryButtonText="Case Study"
            secondaryButtonUrl="#"
            accentColor="#10b981"
            reverse={true}
          />
        </div>
      </div>
    </section>
  );
};

export default CaseStudy;
