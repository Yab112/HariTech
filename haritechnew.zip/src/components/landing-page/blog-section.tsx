import { ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import DualTitle from "../dual-title";

interface BlogPost {
  id: string;
  date: string;
  title: string;
  description: string;
  image: string;
  tags: {
    name: string;
    color?: string;
  }[];
}

export default function BlogSection() {
  const blogPosts: BlogPost[] = [
    {
      id: "1",
      date: "1 Jan 2023",
      title: "How to Scale Your Trade Business Without Increasing",
      description:
        "Growth doesn't have to mean more expenses. Discover strategies to scale your trade business with technology while keeping",
      image: "/blog.png?height=300&width=400",
      tags: [
        { name: "BusinessGrowth", color: "text-purple-600 bg-purple-100 " },
        { name: "Scalability", color: "text-orange-600 bg-orange-100" },
      ],
    },
    {
      id: "2",
      date: "1 Jan 2023",
      title: "UTRADIE vs. Traditional Job Management",
      description:
        "Is manual job tracking holding your business back? See how UTRADIE simplifies operations compared to traditional methods.",
      image: "/blog.png?height=300&width=400",
      tags: [
        { name: "UTRADIE", color: "text-blue-600 bg-blue-100" },
        { name: "JobManagement", color: "text-purple-600 bg-purple-100 " },
        { name: "Efficiency", color: "text-orange-600 bg-orange-100" },
      ],
    },
    {
      id: "3",
      date: "1 Jan 2023",
      title: "The Role of Admin Automation in Trade Businesse",
      description:
        "Admin work can slow down business operations. Learn how ADMINOH helps trade businesses workflow..",
      image: "/blog.png?height=300&width=400",
      tags: [
        { name: "ADMINOH", color: "text-purple-600 bg-purple-100" },
        { name: "BusinessAutomation", color: "text-purple-600 bg-purple-100 " },
      ],
    },
  ];

  return (
    <section className="w-full bg-[#F0F3F5] py-8 md:py-10">
      <div className="container mx-auto">
        <DualTitle
          firstTitle="Our"
          secondTitle="Blogs"
          //   subtitle="Helping tradies and businesses streamline operations with intuitive technology."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogPosts.map((post) => (
            <div
              key={post.id}
              className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100"
            >
              <div className="relative h-56 px-3 pt-3">
                <img
                  src={post.image || "/placeholder.svg"}
                  alt={post.title}
                  className="object-cover w-full h-full rounded"
                />
              </div>
              <div className="p-4">
                <p className="text-purple-600 text-sm font-medium mb-2">
                  {post.date}
                </p>
                <div className="flex justify-between items-start gap-2 mb-3">
                  <h3 className="text-xl font-semibold leading-tight text-black">
                    {post.title}
                  </h3>
                  <ArrowUpRight className="h-5 w-5 flex-shrink-0 text-gray-400" />
                </div>
                <p className="text-gray-600 text-sm mb-4">{post.description}</p>
                <div className="flex flex-wrap gap-2">
                  {post.tags.map((tag, index) => (
                    <span
                      key={index}
                      className={`text-sm px-3 py-[2px] rounded-full ${
                        tag.color || "text-gray-700"
                      }`}
                    >
                      {tag.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-8">
          <Link
            to="#"
            className="inline-flex items-center gap-2 bg-primary text-white px-6 py-2 rounded-full font-medium hover:bg-primary transition-colors"
          >
            Read More
            <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
