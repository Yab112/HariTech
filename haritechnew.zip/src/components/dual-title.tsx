import { cn } from "@/lib/utils";

interface DualTitleProps {
  firstTitle: string;
  secondTitle: string;
  subtitle?: string;
  className?: string;
}

export default function DualTitle({
  firstTitle,
  secondTitle,
  subtitle,
  className = "",
}: DualTitleProps) {
  return (
    <div
      className={cn(`px-4 py-6 sm:px-6 sm:py-8 md:px-8 md:py-10  `, className)}
    >
      <div className="max-w-4xl mx-auto text-center relative">
        <h1 className="text-xl sm:text-2xl md:text-3xl font-semibold leading-tight  relative z-[1] max-w-md mx-auto ">
          <div className=" absolute -bottom-5 z-[-1]  left-1/2 w-3/4 -translate-x-1/2">
            <img src="/title-line.svg" alt="" className="w-full" />
          </div>
          <span className="text-black">{firstTitle}</span>{" "}
          <span className="text-emerald-500">{secondTitle}</span>
        </h1>
        {subtitle && (
          <p className=" mt-4 text-sm sm:text-base  text-gray-700 max-w-[450px] mx-auto leading-relaxed">
            {subtitle}
          </p>
        )}
      </div>
    </div>
  );
}
