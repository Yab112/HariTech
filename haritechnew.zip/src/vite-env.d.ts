/// <reference types="vite/client" />

declare const global: {
    basename: string
}
