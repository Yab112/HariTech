import { cn } from "@/lib/utils";

export interface ProductShowcaseProps {
  subtitle: string;
  title: string;
  highlightedText: string;
  description: string;
  imageSrc: string;
  imageAlt: string;
  primaryButtonText?: string;
  primaryButtonUrl?: string;
  secondaryButtonText?: string;
  secondaryButtonUrl?: string;
  accentColor?: string;
  reverse?: boolean;
}

export function ProductShowcase({
  subtitle,
  title,
  highlightedText,
  description,
  imageSrc,
  imageAlt,
  primaryButtonText,
  primaryButtonUrl,
  secondaryButtonText,
  secondaryButtonUrl,
  accentColor = "#10b981",
  reverse = false,
}: ProductShowcaseProps) {
  return (
    <section className="w-full py-12 md:py-16 rounded-2xl bg-white">
      <div
        className={cn(
          "flex flex-col lg:gap-12 gap-6 md:gap-8 items-center px-14",
          reverse ? "md:flex-row-reverse" : "md:flex-row"
        )}
      >
        <div className="flex-1">
          <div className="relative w-full max-w-[600px] mx-auto">
            <img
              src={imageSrc || "/placeholder.svg"}
              alt={imageAlt}
              width={600}
              height={400}
              className="w-full h-auto object-cover"
            />
          </div>
        </div>
        <div className="flex-1">
          <ProductContent
            subtitle={subtitle}
            title={title}
            highlightedText={highlightedText}
            description={description}
            primaryButtonText={primaryButtonText}
            primaryButtonUrl={primaryButtonUrl}
            secondaryButtonText={secondaryButtonText}
            secondaryButtonUrl={secondaryButtonUrl}
            accentColor={accentColor}
          />
        </div>
      </div>
    </section>
  );
}

import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";

export interface ProductContentProps {
  subtitle: string;
  title: string;
  highlightedText: string;
  description: string;
  primaryButtonText?: string;
  primaryButtonUrl?: string;
  secondaryButtonText?: string;
  secondaryButtonUrl?: string;
  accentColor?: string;
  className?: string;
}

export function ProductContent({
  subtitle,
  title,
  highlightedText,
  description,
  primaryButtonText = "View Website",
  primaryButtonUrl = "#",
  accentColor = "#10b981",
  className,
}: ProductContentProps) {
  return (
    <div className={cn("flex flex-col   space-y-6", className)}>
      <div className="space-y-2  flex flex-col max-md:items-center">
        <div className="flex items-center gap-2">
          <div
            className="w-6 h-1 rounded-full"
            style={{ backgroundColor: accentColor }}
          ></div>
          <span className="text-lg font-medium text-black">{subtitle}</span>
        </div>
        <h2 className="md:text-xl text-lg font-semibold max-md:text-center tracking-tight lg:text-2xl text-black">
          {title}
          <br />
          <span style={{ color: accentColor }}>{highlightedText}</span>
        </h2>
      </div>
      <p className="text-gray-600 max-md:text-center max-w-prose">
        {description}
      </p>
      <div className="pt-2 w-full  ">
        {primaryButtonText && (
          <Link
            to={primaryButtonUrl}
            className="inline-flex max-md:w-full items-center bg-primary justify-center rounded-full px-6 py-2 text-base  text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50"
          >
            {primaryButtonText} <ArrowUpRight className="ml-2 h-4 w-4" />
          </Link>
        )}
        {/* {secondaryButtonText && (
          <Link
            to={secondaryButtonUrl}
            className="inline-flex items-center justify-center rounded-full border border-gray-200 bg-white px-6 py-2 text-base  text-gray-900 transition-colors hover:bg-gray-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50"
          >
            {secondaryButtonText} <ArrowUpRight className="ml-2 h-4 w-4" />
          </Link>
        )} */}
      </div>
    </div>
  );
}
