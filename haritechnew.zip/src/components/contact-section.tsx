import type React from "react";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function ContactSection() {
  const [email, setEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission logic here
    console.log("Email submitted:", email);
  };

  return (
    <div className="mx-auto max-w-7xl pb-4">
      <div className="relative  bg-emerald-500 rounded-2xl">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `linear-gradient(to right, rgba(255, 255, 255, 0.1) 1px, transparent 1px), 
                    linear-gradient(to bottom, rgba(255, 255, 255, 0.1) 1px, transparent 1px)`,
            backgroundSize: "40px 40px",
          }}
        ></div>
        <div className=" hidden md:block absolute -top-[140px] left-[25%]  w-full max-w-md scale-75">
          <img
            src="/contact.svg"
            alt="Construction professional with laptop"
            className="w-full  object-contain"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 relative z-10 ">
          {/* Left column */}
          <div className="pt-6 max-md:text-center md:p-12 flex flex-col justify-center">
            <h2 className="text-white text-3xl md:text-4xl font-semibold leading-tight">
              Got an Idea?
              <br />
              Let's Chat.
            </h2>
          </div>

          {/* Right column */}
          <div className="p-8 md:p-12 flex flex-col justify-center items-end">
            <p className="text-white text-right text-lg mb-8 max-w-md  max-md:text-center">
              Want to partner with Grow2, bring your skills to the table, or
              just float an idea? We're all ears — drop your details and let's
              talk.
            </p>

            <form
              onSubmit={handleSubmit}
              className="flex flex-col sm:flex-row gap-3 relative w-[320px] border border-white rounded-full "
            >
              <Input
                type="email"
                placeholder="Enter Your Email"
                className="bg-white/20 border-0 text-white placeholder:text-white/70 h-12 rounded-full px-6 "
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Button
                type="submit"
                className=" text-white font-medium rounded-full px-4 absolute right-1 top-1/2 -translate-y-1/2 "
              >
                Get Started
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
