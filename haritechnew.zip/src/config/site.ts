export const siteConfig = {
    name: "UTRADIE",
    description:
        "Empowering the Future of Trades Connect, Learn, and Build with Utradie Where Opportunities Meet Skilled Hands.",
    url: "https://utradie.com",
    keyWords: []

}
