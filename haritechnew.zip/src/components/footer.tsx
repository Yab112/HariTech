import { Button } from "@/components/ui/button";
import { Facebook, Twitter, Instagram } from "lucide-react";
import ContactSection from "./contact-section";
import { Link } from "react-router-dom";

export default function Footer({ bgColor = "bg-white" }: { bgColor?: string }) {
  return (
    <footer>
      <div className={`${bgColor} ] relative md:pt-24`}>
        <div className=" absolute inset-x-0 bg-background h-1/2 bottom-0"></div>
        <ContactSection />
      </div>
      <div className="bg-background text-white  pb-4 px-4 pt-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className=" max-md:col-span-2">
              <h3 className=" mb-6">Ready to get started?</h3>
              <Link to={"/product"}>
                <Button className="bg-emerald-500 hover:bg-emerald-600 text-white w-full md:w-auto">
                  Our Products
                </Button>
              </Link>
            </div>

            <div>
              <h3 className="text- font-medium mb-6">Products</h3>
              <ul className="space-y-3 text-sm">
                <li>
                  <Link
                    to="https://utradie.com"
                    className="hover:text-emerald-400 transition-colors"
                  >
                    UTRADIE
                  </Link>
                </li>
                <li>
                  <Link
                    to="#"
                    className="hover:text-emerald-400 transition-colors"
                  >
                    AdminOh
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-medium mb-6">About</h3>
              <ul className="space-y-3 text-sm">
                <li>
                  <Link
                    to="/about#story"
                    className="hover:text-emerald-400 transition-colors"
                  >
                    Our Story
                  </Link>
                </li>
                <li>
                  <Link
                    to="/about#benefit"
                    className="hover:text-emerald-400 transition-colors"
                  >
                    Benefits
                  </Link>
                </li>
                <li>
                  <Link
                    to="/about#team"
                    className="hover:text-emerald-400 transition-colors"
                  >
                    Team
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-medium mb-6">Help</h3>
              <ul className="space-y-3 text-sm">
                <li>
                  <Link
                    to="/#faq"
                    className="hover:text-emerald-400 transition-colors"
                  >
                    FAQs
                  </Link>
                </li>
                <li>
                  <Link
                    to="/contact"
                    className="hover:text-emerald-400 transition-colors"
                  >
                    Contact Us
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center mt-4  pt-8  border-slate-800">
            <div className="flex space-x-6 mb-4 md:mb-0">
              <Link
                to="#"
                className="hover:text-emerald-400 transition-colors opacity-0"
              >
                Terms & Conditions
              </Link>
              <Link
                to="#"
                className="hover:text-emerald-400 transition-colors  opacity-0"
              >
                Privacy Policy
              </Link>
            </div>

            <div className="flex space-x-4">
              <Link to="#" className="hover:text-emerald-400 transition-colors">
                <Facebook size={24} />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link to="#" className="hover:text-emerald-400 transition-colors">
                <Twitter size={24} />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link to="#" className="hover:text-emerald-400 transition-colors">
                <Instagram size={24} />
                <span className="sr-only">Instagram</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
