import {
  DollarSign,
  Users,
  Smartphone,
  Shield,
  TrendingUp,
} from "lucide-react";
import { Link } from "react-router-dom";
import DualTitle from "../dual-title";

const WhatSetUsApart = () => {
  return (
    <section id="benefit" className="w-full bg-[#F0F3F5]  py-16 md:py-10">
      <div className="container mx-auto px-4">
        <DualTitle
          firstTitle="What Sets"
          secondTitle=" Us Apart"
          //   subtitle="Helping tradies and businesses streamline operations with intuitive technology."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Card 1 */}
          <div className="bg-background text-white p-6 rounded-lg shadow-sm">
            <div className="flex gap-4 items-center">
              <div className="bg-white w-10 h-10 rounded-lg flex items-center justify-center mb-4">
                <DollarSign className="text-primary" size={24} />
              </div>
              <h3 className="md:text-xl font-medium text-white mb-3">
                Real Innovation
              </h3>
            </div>
            <p className="text-white">
              We don't build flashy features for fun we solve real tradie
              problems with smart tools that actually save time, and reduce the
              daily chaos.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex gap-4 items-center">
              <div className="bg-primary w-10 h-10  rounded-lg flex items-center justify-center mb-4">
                <Users className="text-white" size={24} />
              </div>
              <h3 className="md:text-xl text-lg font-medium text-primary mb-3 flex-1">
                Human Support Not Just Help Docs
              </h3>
            </div>
            <p className="text-gray-700">
              Stuck? Got a weird idea? Want to chat to someone who gets tradie
              life? We're real people behind the screen — not bots or call
              centres.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex gap-4 items-center">
              <div className="bg-primary w-10 h-10 rounded-lg flex items-center justify-center mb-4">
                <Smartphone className="text-white" size={24} />
              </div>
              <h3 className="md:text-xl text-lg font-medium text-primary mb-3 flex-1">
                Built From the Ground Up (With You)
              </h3>
            </div>
            <p className="text-gray-700">
              Every feature comes from feedback — not a boardroom. We listen,
              test, and tweak until it works on-site, not just on paper.
            </p>
          </div>

          {/* Card 4 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex gap-4 items-center">
              <div className="bg-primary w-10 h-10 rounded-lg flex items-center justify-center mb-4">
                <Smartphone className="text-white" size={24} />
              </div>
              <h3 className="md:text-xl text-lg font-medium text-primary mb-3 flex-1">
                Rock-Solid Reliability
              </h3>
            </div>
            <p className="text-gray-700">
              Our tools are simple, secure, and work when you need them to —
              even when the Wi-Fi's dodgy and the crew's already three smoko
              breaks behind.
            </p>
          </div>

          {/* Card 5 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex gap-4 items-center">
              <div className="bg-primary w-10 h-10 rounded-lg flex items-center justify-center mb-4">
                <Shield className="text-white" size={24} />
              </div>
              <h3 className="md:text-xl text-lg font-medium text-primary mb-3">
                Straightforward Scalability
              </h3>
            </div>
            <p className="text-gray-700">
              From one-man bands to big crews, our systems are built to handle
              whatever pace you're growing at — without falling apart.
            </p>
          </div>

          {/* Card 6 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex gap-4 items-center">
              <div className="bg-primary w-10 h-10 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="text-white" size={24} />
              </div>
              <h3 className="md:text-xl text-lg font-medium text-primary mb-3">
                Grows With You
              </h3>
            </div>
            <p className="text-gray-700 flex-1">
              Whether you're solo with a phone or running a full team, our
              platforms flex to fit your business as it grows.
            </p>
          </div>
        </div>

        <div className="flex justify-center mt-12">
          <Link
            to="#products"
            className="bg-primary text-white max-md:flex-1 justify-center px-6 py-2 rounded-full font-medium flex items-center gap-2 hover:bg-primary/90 transition-colors"
          >
            Our Products
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M7 17L17 7M17 7H7M17 7V17"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default WhatSetUsApart;
