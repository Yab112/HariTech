import React from "react";
import { ProductShowcase } from "./product-showcase";
import DualTitle from "../dual-title";

const Showcase = () => {
  return (
    <section className="w-full py-8 md:py-10">
      <DualTitle
        firstTitle="Our Tools, "
        secondTitle="Built for Trade Legends"
        subtitle="Simplifying your day. Powering your business."
      />
      <div className=" container mx-auto px-4  flex flex-col gap-6 items-center justify-between">
        <ProductShowcase
          brandName="UTRADIE"
          headline="Train, Brief, And Grow Your"
          highlightedText="Team Without The Repetition."
          description="UTRADIE lets you create and deliver training, briefs, and how-tos with cards that include video, text, and checklists. It keeps everyone aligned, whether onboarding new apprentices or upskilling your team."
          features={[
            "Build once, use forever",
            "Deliver info to your team instantly",
            "Track who's seen what",
            "Great for apprentices, business owners & schools",
          ]}
          imageUrl="/uthradie-pc.png?height=600&width=800"
          imageAlt="UTRADIE dashboard on laptop"
          viewWebsiteUrl="https://utradie.com"
          caseStudyUrl="#"
          imageOnRight={false}
          accentColor="emerald-500"
        />

        {/* AdminOh Example */}
        <ProductShowcase
          brandName="AdminOh"
          headline="Hand Off Your Admin."
          highlightedText="We'll Get It Sorted."
          description="AdminOh connects you with real humans to handle admin tasks—like feedback collection, chasing documents, posting on socials, formatting invoices, and building reports. Buy credits, post a task, and it's done. Simple."
          features={[
            "Real people, not bots",
            "Use credits only when you need help",
            'Handles those "I\'ll do it later" tasks',
            "Great for busy business owners, sole traders & growing teams",
          ]}
          imageUrl="/adminoh.png?height=400&width=600"
          imageAlt="AdminOh website on laptop"
          viewWebsiteUrl="http://www.adminoh.com/"
          caseStudyUrl="#"
          imageOnRight={true}
          accentColor="emerald-500"
        />
      </div>
    </section>
  );
};

export default Showcase;
