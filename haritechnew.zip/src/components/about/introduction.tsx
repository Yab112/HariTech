import { Link } from "react-router-dom";

const Introduction = () => {
  return (
    <section className="w-full bg-white  h-screen  py-8 md:py-10">
      <div className="flex flex-col-reverse md:flex-row lg:gap-12 md:items-center container mx-auto px-4 h-full  max-md:mt-16">
        <div className="md:mt-16  flex-1 ">
          <h2 className="lg:text-5xl md:text-4xl text-3xl max-md:text-center  font-semibold mb-6 font-lexend">
            Built by People <br />
            Who Get It
          </h2>
          <p className=" text-gray-700 mb-6 max-w-md max-md:text-center">
            At Grow2, we're tradies, business owners, and problem-solvers. We
            build tools like UTRADIE and AdminOh because we've lived the chaos —
            juggling jobs, training crews, chasing paperwork, and wondering,
            "Why hasn't someone fixed this already?"
          </p>
          <Link
            to="/contact"
            className="bg-primary justify-center max-md:w-full text-white px-6 py-2 rounded-full font-medium inline-flex items-center gap-2 hover:bg-primary/90 transition-colors"
          >
            Learn More
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M19 9L12 16L5 9"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </Link>
        </div>
        <div className=" relative flex-1">
          <img
            src="/about-hero.png"
            alt="Tradie with hard hat"
            width={600}
            height={600}
            className=" h-full md:scale-110  flex-1"
          />
        </div>
      </div>
    </section>
  );
};

export default Introduction;
