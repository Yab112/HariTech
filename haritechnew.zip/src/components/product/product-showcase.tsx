import { CheckCircle, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

interface ProductShowcaseProps {
  brandName: string;
  headline: string;
  highlightedText?: string;
  description: string;
  features: string[];
  imageUrl: string;
  imageAlt: string;
  viewWebsiteUrl: string;
  caseStudyUrl: string;
  imageOnRight?: boolean;
  accentColor?: string;
}

export function ProductShowcase({
  brandName,
  headline,
  highlightedText,
  description,
  features,
  imageUrl,
  imageAlt,
  viewWebsiteUrl,
  caseStudyUrl,
  imageOnRight = true,
  accentColor = "emerald-500",
}: ProductShowcaseProps) {
  return (
    <div className="w-full py-6 md:py-12 lg:py-16 rounded-2xl bg-white">
      {/* <div className="container px-4 md:px-10"> */}
      <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12 md:px-14 px-6">
        {/* Content Section */}
        <div
          className={cn(
            "flex-1 md:space-y-6 space-y-4  flex flex-col max-md:items-center",
            imageOnRight ? "md:order-1" : "md:order-2"
          )}
        >
          {/* Brand Name */}
          <div className="flex items-center gap-2 ">
            <div className={`h-1.5 w-8 bg-${accentColor} rounded-full`}></div>
            <span className="font-semibold text-lg">{brandName}</span>
          </div>

          {/* Headline */}
          <div className="space-y-1 max-md:text-center ">
            <h2 className="text-xl md:text-2xl font-semibold">{headline}</h2>
            {highlightedText && (
              <h2
                className={`text-xl md:text-2xl font-semibold text-${accentColor}`}
              >
                {highlightedText}
              </h2>
            )}
          </div>

          {/* Description */}
          <p className="text-gray-700 max-md:text-center">{description}</p>

          {/* Features */}
          <ul className="space-y-3">
            {features.map((feature, index) => (
              <li key={index} className="flex items-start gap-3">
                <CheckCircle
                  className={`h-5 w-5 text-${accentColor} mt-0.5 flex-shrink-0`}
                />
                <span>{feature}</span>
              </li>
            ))}
          </ul>

          {/* CTAs */}
          <div className=" w-full gap-4 pt-2">
            <Link
              to={viewWebsiteUrl}
              className="inline-flex max-md:w-full justify-center items-center gap-2 px-6 py-2 rounded-full bg-primary text-white  hover:bg-primary transition-colors"
            >
              View Website
              <ArrowUpRight />
            </Link>
            {/* <Link
              to={caseStudyUrl}
              className="inline-flex items-center gap-2 px-6 py-2 rounded-full bg-white text-primbg-primary  border border-gray-200 hover:bg-gray-50 transition-colors"
            >
              Case Study
              <ArrowUpRight />
            </Link> */}
          </div>
        </div>

        {/* Image Section */}
        <div
          className={cn(
            "flex-1 relative",
            imageOnRight ? "md:order-2" : "md:order-1"
          )}
        >
          <div
            className={cn(
              "relative z-10",
              imageOnRight ? "md:-mr-12" : "md:-ml-12"
            )}
          >
            <img
              src={imageUrl || "/placeholder.svg"}
              alt={imageAlt}
              width={600}
              height={400}
              className="w-full h-auto"
            />
          </div>
          <div
            className={cn(
              `absolute w-64 h-64 rounded-full bg-${accentColor}/30 -z-10`,
              imageOnRight ? "bottom-0 right-0" : "bottom-0 left-0"
            )}
          ></div>
        </div>
      </div>
    </div>
  );
}
