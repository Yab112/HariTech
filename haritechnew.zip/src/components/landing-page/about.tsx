import { MessageCircle, ArrowUpRight, Target, Video } from "lucide-react";
import React from "react";
import { Link } from "react-router-dom";
import DualTitle from "../dual-title";

const AboutUs = () => {
  return (
    <section className="w-full bg-white py-8 md:py-10">
      <div className="container mx-auto px-4 ">
        <DualTitle
          firstTitle="Keep the Crew Running,"
          secondTitle="Without Losing Your Mind"
          subtitle="UTRADIE trains your team. AdminOh takes on your to-dos. Together,
              they keep your business sharp, simple, and scalable."
        />

        {/* Main Content */}
        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Left Column - Image */}
          <div className="relative">
            <img
              src="/about.svg?height=600&width=600"
              alt="Construction worker using tablet"
              width={600}
              height={600}
              className="object-cover"
            />
          </div>
          <div className="space-y-10">
            {/* UTRADIE Section */}
            <div>
              <h2 className="text-lg md:text-xl max-md:text-center font-semibold text-black max-w-[350px] mb-4">
                UTRADIE: Built to help you say it once — not fifty bloody times.
              </h2>
              <p className="text-gray-700  max-md:text-center">
                UTRADIE helps you turn rough ideas into clean, repeatable
                training. Whether it's a quick how-to video, checklist, or a
                proper trade course — we help you build it once and deliver it
                to your team anytime, anywhere.
              </p>
            </div>

            {/* AdminOh Section */}
            <div>
              <h2 className="text-lg md:text-xl  max-md:text-center font-semibold text-black max-w-[350px] mb-4">
                AdminOh: Less BS. More Done.
              </h2>
              <p className="text-gray-700  max-md:text-center">
                With AdminOh, you post the task — we chase it down. Feedback
                forms, social posts, checklists, inbox clutter... whatever's
                clogging up your brain or your calendar, hand it off and we'll
                sort it.
              </p>
            </div>

            {/* About Us Button */}
            <div>
              <Link
                to="/about"
                className="inline-flex items-center  max-md:w-full justify-center gap-2 bg-primary text-white px-6 py-2 rounded-full font-medium hover:bg-primary transition-colors"
              >
                About Us <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
