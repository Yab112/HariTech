import { cn } from "@/lib/utils";
import DualTitle from "../dual-title";

const teamMembers = [
  {
    name: "Marc Webb",
    role: "Founder",
    description:
      "Ex-tradie turned tech apprentice. Still learning. Still building. Still backing the industry that built him.",
    bgColor: "bg-[#0a3049] text-white",
  },
  {
    name: "Peter Beardsley",
    role: "Co-Founder & Head of Development",
    description:
      "Code whisperer. Bug killer. Keeps UTRADIE and AdminOh running smoother than a new Makita.",
  },
  {
    name: "Amir Getnet",
    role: "Operations Assistant",
    description:
      "Keeps the team organized, the tasks moving, and the wheels turning — with zero panic.",
  },
  {
    name: "Salem Getnet",
    role: "Marketing",
    description:
      "Builds the buzz, writes the words, and makes sure tradies actually see what we're building.",
  },
  {
    name: "Miracle Afamefune",
    role: "Public Relations",
    description:
      "Brings the voice, the message, and the people skills. If it sounds good out there — that's Miracle.",
  },
  {
    name: "Eden Gelan",
    role: "Design",
    description:
      "Turns ideas into visuals. Makes everything look sharp, clean, and on-brand — even when we're sending it last minute.",
  },
  {
    name: "Abel Nigus",
    role: "Front-End Developer",
    description:
      "Everything you see and click — that's Abel's work. Clean, fast, and built to feel like butter.",
  },
  {
    name: "Dawit Habitamu",
    role: "Back-End Developer",
    description:
      "The tech backbone. Dawit keeps the logic, data, and systems humming quietly behind the scenes.",
  },
];

export function TeamSection() {
  return (
    <section id="team" className="w-full bg-[#F0F3F5] py-8 md:py-10">
      <div className="container mx-auto px-4">
        <DualTitle
          firstTitle="The Experts"
          secondTitle="behind our success"
          subtitle="Real people. Real experience. Real good at what they do."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 bg-gray-100">
          {teamMembers.map((member, index) => (
            <TeamMemberCard
              key={index}
              name={member.name}
              role={member.role}
              description={member.description}
              bgColor={member.bgColor}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

interface TeamMemberCardProps {
  name: string;
  role: string;
  description: string;
  bgColor?: string;
}

export function TeamMemberCard({
  name,
  role,
  description,
  bgColor,
}: TeamMemberCardProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center p-6 text-center h-full rounded-xl",
        bgColor ? bgColor : "bg-white"
      )}
    >
      <div className="relative mb-4">
        <div className="w-24 h-24 bg-gray-300 rounded-full overflow-hidden flex items-center justify-center">
          <img
            src="/placeholder.png?height=96&width=96"
            alt={name}
            width={96}
            height={96}
            className="object-cover"
          />
        </div>
      </div>
      <h3 className="text-lg font-semibold">{name}</h3>
      <p className="text-sm mb-3">{role}</p>
      <p className={cn("text-sm", bgColor ? "text-white/90" : "text-gray-600")}>
        {description}
      </p>
    </div>
  );
}
