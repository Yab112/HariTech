import { ChevronDown } from "lucide-react";
import { Link } from "react-router-dom";

export default function ProductHeroSection() {
  return (
    <section className="w-full  min-h-screen relative bg-white  py-8 md:py-10 ">
      <div className="container mx-auto  px-4 flex flex-col lg:flex-row items-center   ">
        <div className="w-full lg:w-1/2 mb-10 lg:mb-0 md:mt-52 mt-20 max-md:flex flex-col items-center ">
          <h1 className="text-3xl max-md:text-center md:text-4xl lg:text-5xl font-semibold leading-tight text-[#111] font-lexend">
            Two Products. One Mission:
          </h1>

          <div className="relative inline-block font-lexend">
            <div
              className="relative z-10 inline-block bg-primary rounded-lg text-2xl md:text-3xl lg:text-4xl font-semibold "
              style={{
                transform: "skew(-6deg)",
                paddingTop: "0.25rem",
                paddingBottom: "0.5rem",
                paddingLeft: "1.5rem",
                paddingRight: "1.5rem",
              }}
            >
              <span
                className="inline-block text-white "
                style={{ transform: "skew(6deg)" }}
              >
                Less Stuff-Ups.
              </span>
            </div>
          </div>
          <p className="text-lg md:text-xl max-md:text-center text-[#333] mt-4">
            Designed by tradies, tested on-site.
          </p>
          <Link
            to={"/contact"}
            className="bg-primary hidden md:flex text-white px-6 py-2 mt-4 rounded-full  items-center gap-2 hover:bg-primary/90 transition-colors w-fit"
          >
            Learn More <ChevronDown className="h-5 w-5" />
          </Link>
        </div>
      </div>
      <div className="w-full lg:w-1/2  md:absolute top-0 bottom-0 right-0 overflow-hidden">
        <div className="relative ">
          <img
            src="/product-hero.png?height=600&width=500"
            alt="Construction worker with clipboard"
            className="object-contain h-full "
          />
        </div>
      </div>
    </section>
  );
}
