import ScrollTimeline from "@/components/about/history";
import Introduction from "@/components/about/introduction";
import { TeamSection } from "@/components/about/team-member";
import WhatSetUsApart from "@/components/about/what-sets-us-apart";
import Footer from "@/components/footer";

const AboutPage = () => {
  return (
    <div>
      <Introduction />
      <WhatSetUsApart />
      <ScrollTimeline />
      <TeamSection />
      <Footer bgColor="bg-[#F0F3F5]" />
    </div>
  );
};

export default AboutPage;
