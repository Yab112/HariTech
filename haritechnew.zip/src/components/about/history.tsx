"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import DualTitle from "../dual-title";

type TimelineSection = {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  content: string;
  phase: "Past" | "Present" | "Future";
};

export default function ScrollTimeline() {
  const [activeSection, setActiveSection] = useState(0);
  const sectionRefs = useRef<(HTMLDivElement | null)[]>([]);

  const sections: TimelineSection[] = [
    {
      id: "past",
      number: "01",
      title: "The Apprenticeship Begins (2015-2022)",
      subtitle: "Past",
      content:
        'Grow2 was born on worksites — not in offices. With no background in tech, stepping into the software world was like starting a second apprenticeship: full of setbacks, late nights, and plenty of "what the hell does that even mean?" moments. Through dodgy devs, clunky prototypes, and brutal lessons, one thing stayed clear: the trade world deserves better tools. That belief is what kept us swinging.',
      phase: "Past",
    },
    {
      id: "present",
      number: "02",
      title: "Tools That Tradies Actually Use",
      subtitle: "Present",
      content:
        "Today, Grow2 has two powerful products — UTRADIE and AdminOn — both shaped by feedback from real people on the tools. We're still refining, still learning, and still testing everything against one question: \"Does this actually help on site?\" No fluff. No features for features' sake. Just solid tools built to make life easier.",
      phase: "Present",
    },
    {
      id: "future",
      number: "03",
      title: "FUTURE - Built With You, For What's Next",
      subtitle: "Future",
      content:
        "Grow2 isn't done — we're just warming up. From smarter systems to tighter crew training, we're working on tools that grow as you do. This isn't about flashy tech. It's about backing the people who build the world — with the tools to back them.",
      phase: "Future",
    },
  ];

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + window.innerHeight / 3;

      sectionRefs.current.forEach((section, index) => {
        if (!section) return;

        const sectionTop = section.offsetTop;
        const sectionBottom = sectionTop + section.offsetHeight;

        if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
          setActiveSection(index);
        }
      });
    };

    window.addEventListener("scroll", handleScroll);
    handleScroll(); // Initialize on mount

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div id="story" className="min-h-[200vh] bg-white">
      {/* Fixed header */}
      <div className="sticky top-0 pt-4 pb-4 bg-white z-10">
        <DualTitle
          firstTitle="From Startup to"
          secondTitle="Great Product"
          subtitle="The only tools you need to streamline, scale,
            and succeed."
        />
      </div>

      <div className="relative max-w-4xl mx-auto px-4 flex b">
        {/* Sticky Timeline */}
        <div className="sticky top-[198px] h-[calc(100vh-10rem)] w-32 flex flex-col items-center">
          <div className="flex flex-col items-center h-full relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 top-6 bottom-6 w-0.5 bg-emerald-100"></div>

            {/* Past */}
            <div className="flex flex-col items-center z-10 mb-auto">
              <motion.div
                className="text-lg font-medium mb-2"
                animate={{ color: activeSection >= 0 ? "#10b981" : "#9ca3af" }}
                transition={{ duration: 0.5 }}
              >
                Past
              </motion.div>
              <motion.div
                className="w-6 h-6 rounded-full border-2 flex items-center justify-center relative"
                animate={{
                  backgroundColor: activeSection >= 0 ? "#10b981" : "#ffffff",
                  borderColor: "#10b981",
                }}
                transition={{ duration: 0.5 }}
              >
                {activeSection >= 0 && (
                  <motion.div
                    className="w-2 h-2 bg-white rounded-full"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                )}
              </motion.div>
            </div>

            {/* Present */}
            <div className="flex flex-col items-center z-10 my-auto">
              <motion.div
                className="text-lg font-medium mb-2"
                animate={{ color: activeSection >= 1 ? "#10b981" : "#9ca3af" }}
                transition={{ duration: 0.5 }}
              >
                Present
              </motion.div>
              <motion.div
                className="w-6 h-6 rounded-full border-2 flex items-center justify-center relative"
                animate={{
                  backgroundColor: activeSection >= 1 ? "#10b981" : "#ffffff",
                  borderColor: activeSection >= 1 ? "#10b981" : "#d1d5db",
                  borderStyle: activeSection >= 1 ? "solid" : "solid",
                }}
                transition={{ duration: 0.5 }}
              >
                {activeSection >= 1 && (
                  <motion.div
                    className="w-2 h-2 bg-white rounded-full"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                )}
              </motion.div>
            </div>

            {/* Future */}
            <div className="flex flex-col items-center z-10 mt-auto">
              <motion.div
                className="text-lg font-medium mb-2"
                animate={{ color: activeSection >= 2 ? "#10b981" : "#9ca3af" }}
                transition={{ duration: 0.5 }}
              >
                Future
              </motion.div>
              <motion.div
                className="w-6 h-6 rounded-full border-2 flex items-center justify-center relative"
                animate={{
                  backgroundColor: activeSection >= 2 ? "#10b981" : "#ffffff",
                  borderColor: activeSection >= 2 ? "#10b981" : "#d1d5db",
                  borderStyle: activeSection >= 2 ? "solid" : "dashed",
                }}
                transition={{ duration: 0.5 }}
              >
                {activeSection >= 2 && (
                  <motion.div
                    className="w-2 h-2 bg-white rounded-full"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                )}
              </motion.div>
            </div>
          </div>
        </div>

        {/* Content sections */}
        <div className="flex-1">
          {sections.map((section, index) => (
            <div
              key={section.id}
              ref={(el) => (sectionRefs.current[index] = el)}
              className="min-h-[90vh] pt-16"
            >
              <div className="flex items-center mb-4">
                <div className="lg:text-[120px] md:text-[100px]  text-[80px] font-bold text-gray-200 leading-none">
                  {section.number}
                </div>
                <div className="ml-4 text-emerald-500">{section.subtitle}</div>
              </div>

              <h2 className="lg:text-3xl md:text-2xl text-xl font-bold mb-4">
                {section.title}
              </h2>

              <p className="text-gray-600 max-w-2xl">{section.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
