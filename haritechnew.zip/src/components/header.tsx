import { cn } from "@/lib/utils";
import { ArrowRight, ArrowUpRight, Menu, X } from "lucide-react";
import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

const Header = () => {
  const { pathname } = useLocation();
  const textColor = pathname == "/" && "text-white";
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Handle scroll effect
  // useEffect(() => {
  //   const handleScroll = () => {
  //     setScrolled(window.scrollY > 20);
  //   };
  //   window.addEventListener("scroll", handleScroll);
  //   return () => window.removeEventListener("scroll", handleScroll);
  // }, []);

  // Close menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [pathname]);

  return (
    <header
      className={cn(
        "container absolute inset-x-0 mx-auto px-4 py-6 z-[100] transition-all duration-300"
      )}
    >
      <nav className="flex items-center justify-between">
        <Link to={"/"} className="flex items-center gap-1 z-50">
          <img src="/logo.svg" alt="" className="w-16" />
          <span className={cn("text-xl font-medium", textColor)}>Grow2</span>
        </Link>

        <div className={cn("hidden md:flex items-center gap-8", textColor)}>
          <Link
            to="/"
            className={cn(
              "font-medium hover:text-[#34D399] transition-colors",
              pathname === "/" && "text-[#34D399]"
            )}
          >
            Home
          </Link>
          <Link
            to="/about"
            className={cn(
              "font-medium hover:text-[#34D399] transition-colors",
              pathname === "/about" && "text-[#34D399]"
            )}
          >
            About Us
          </Link>
          <Link
            to="/product"
            className={cn(
              "font-medium hover:text-[#34D399] transition-colors",
              pathname === "/product" && "text-[#34D399]"
            )}
          >
            Products
          </Link>
        </div>

        <Link
          to="/contact"
          className="hidden md:flex items-center gap-2 bg-[#34D399] hover:bg-[#2ebb85] text-white px-6 py-2 rounded-full font-medium transition-colors"
        >
          Contact Us
          <ArrowUpRight className="h-4 w-4" />
        </Link>

        {/* Mobile menu button */}
        <button
          className="md:hidden z-50 p-2 rounded-full bg-[#34D399]/10"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? (
            <X className={cn("w-6 h-6 transition-colors", textColor)} />
          ) : (
            <Menu className={cn("w-6 h-6 transition-colors", textColor)} />
          )}
        </button>

        {/* Mobile menu overlay */}
        <div
          className={cn(
            "fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity duration-300",
            isMenuOpen ? "opacity-100" : "opacity-0 pointer-events-none"
          )}
          onClick={() => setIsMenuOpen(false)}
        />

        {/* Mobile menu panel */}
        <div
          className={cn(
            "fixed top-0 right-0 h-full w-[80%] max-w-sm bg-white z-[10000] shadow-xl transform transition-transform duration-300 ease-in-out flex flex-col",
            isMenuOpen ? "translate-x-0" : "translate-x-full"
          )}
        >
          <div className="flex flex-col p-8 mt-16 space-y-2">
            <Link
              to="/"
              className={cn(
                "text-xl font-medium hover:text-[#34D399] transition-colors",
                pathname === "/" && "text-[#34D399]"
              )}
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/about"
              className={cn(
                "text-xl font-medium hover:text-[#34D399] transition-colors",
                pathname === "/about" && "text-[#34D399]"
              )}
              onClick={() => setIsMenuOpen(false)}
            >
              About Us
            </Link>
            <Link
              to="/product"
              className={cn(
                "text-xl font-medium hover:text-[#34D399] transition-colors",
                pathname === "/product" && "text-[#34D399]"
              )}
              onClick={() => setIsMenuOpen(false)}
            >
              Products
            </Link>

            <div className="pt-2 mt-auto">
              <Link
                to="/contact"
                className="flex items-center justify-center gap-2 bg-[#34D399] hover:bg-[#2ebb85] text-white px-6 py-3 rounded-full font-medium transition-colors w-full"
                onClick={() => setIsMenuOpen(false)}
              >
                Contact Us
                <ArrowUpRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;
