import {  ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";

const Hero = () => {
  return (
    <main className="container mx-auto px-4 py-8 md:py-10 min-h-screen">
      <div className="flex flex-col-reverse md:flex-row items-center md:gap-8 gap-6   lg:gap-12 lg:mt-44 md:mt-36 mt-24 ">
        <div className="md:w-1/2 max-md:text-center">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-semibold leading-tight font-lexend">
            Empowering <span className="text-[#34D399]">Trade</span> <br />
            Businesses with <br />
            <div className="relative inline-block mt-2  font-lexend">
              <div
                className="relative z-10 inline-block bg-white rounded-lg text34xl md:text-4xl lg:text-5xl font-semibold shadow-md"
                style={{
                  transform: "skew(-6deg)",
                  paddingTop: "0.25rem",
                  paddingBottom: "0.5rem",
                  paddingLeft: "1.5rem",
                  paddingRight: "1.5rem",
                }}
              >
                <span
                  className="inline-block text-[#34D399]"
                  style={{ transform: "skew(6deg)" }}
                >
                  Smart Solutions
                </span>
              </div>
            </div>
          </h1>
          <p className="mt-4 text-base md:text-lg max-w-md">
            Our products help you save time, grow your team, and get back to
            doing what you do best.
          </p>
          <Link
            to="/product"
            className="mt-6 w-full md:w-fit justify-center inline-flex items-center gap-2 bg-[#34D399] hover:bg-[#2ebb85] text-white px-5 py-2.5 rounded-full font-medium transition-colors"
          >
            Explore
            <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="md:w-1/2 relative">
          <img src="/hero-graph.svg" alt="" />
        </div>
      </div>
    </main>
  );
};

export default Hero;
