import Footer from "@/components/footer";
import AboutUs from "@/components/landing-page/about";
import BlogSection from "@/components/landing-page/blog-section";
import CaseStudy from "@/components/landing-page/casestudy";
import FAQSection from "@/components/landing-page/faq";
import FeatureSection from "@/components/landing-page/feature-section";
import Hero from "@/components/landing-page/hero";
import ServiceSection from "@/components/landing-page/service";

const LandingPage = () => {
  return (
    <div className=" bg-background text-white">
      <Hero />
      <FeatureSection />
      <ServiceSection />
      <CaseStudy />
      <AboutUs />
      {/* <BlogSection /> */}
      <FAQSection />
      <Footer bgColor="bg-white" />
    </div>
  );
};

export default LandingPage;
