import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import DualTitle from "../dual-title";
import { Icons } from "../icon";

export default function ServiceSection() {
  return (
    <section className="w-full bg-white py-8 md:py-10">
      <div className=" container mx-auto px-4">
        <DualTitle
          firstTitle="Tech Built for"
          secondTitle="Trade"
          subtitle="The only tools you need to stay on top of the job, from the site to
            the office."
        />

        <div className="grid md:grid-cols-2 items-center">
          {/* Left Side - Image */}
          <div className="relative ">
            <img
              src="/man-with-phone.svg"
              alt="Tradesperson using mobile app"
              width={500}
              height={500}
              className="relative z-10 mx-auto"
            />
          </div>

          {/* Right Side - Content */}
          <div className="space-y-4 text-black">
            <div>
              <h3 className="text-lg max-md:text-center md:text-xl font-semibold mb-4">
                At Grow2, We Design Practical Tools That Remove The Daily Grind
                Of Admin And Team Management — Made For Tradies, By People Who
                Get It.
              </h3>
            </div>

            {/* Feature 1 */}
            <div className="flex gap-4 items-center bg-[#f4f0f0] rounded-lg p-4">
              <div className="bg-red-100 p-3 rounded-lg">
                <Icons.Activity className="size-6" />
              </div>
              <div>
                <h4 className="lg:text-lg font-semibold">
                  Hands-Off Admin Help
                </h4>
                <p className="text-gray-600 text-sm">
                  From chasing client feedback to scheduling posts, AdminOh
                  takes care of the admin so you can get on with the real work.
                </p>
              </div>
            </div>

            {/* Feature 2 */}
            <div className="flex gap-4 items-center bg-[#f4f0f0]  rounded-lg p-4">
              <div className="bg-indigo-100 p-3 rounded-lg">
                <Icons.Category className="size-6" />
              </div>
              <div>
                <h4 className="md:text-lg font-semibold">
                  Clear Briefs. Consistent Teams.
                </h4>
                <p className="text-gray-600 text-sm">
                  We help you turn scattered ideas into clean company briefs,
                  ready to upload to UTRADIE — so your crew always knows what's
                  expected.
                </p>
              </div>
            </div>

            {/* Feature 3 */}
            <div className="flex gap-4 items-center bg-[#f4f0f0]  rounded-lg p-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <Icons.Document className="size-6" />
              </div>
              <div>
                <h4 className="md:text-lg font-semibold ">
                  Smarter Data, Better Decisions
                </h4>
                <p className="text-gray-600 text-sm">
                  Both platforms help turn messy info into useful insights —
                  whether it's hours worked, task updates, or customer trends.
                </p>
              </div>
            </div>

            {/* CTA Button */}
            <div className="pt-4 max-md:flex justify-center">
              <Link
                to="/product"
                className="inline-flex w-full md:w-fit justify-center items-center gap-2 bg-primary text-white px-6 py-2 rounded-full font-medium hover:bg-primary transition-colors"
              >
                Our Products
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
