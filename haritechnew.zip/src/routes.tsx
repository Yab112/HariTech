import { createBrowserRouter } from "react-router-dom";
import LandingPage from "./pages";
import { AppLayout } from "./components/layout/app-layout";
import NoMatch from "./pages/NoMatch";
import AboutPage from "./pages/About";
import ProductPage from "./pages/Product";
import ContactPage from "./pages/Contact";

export const router = createBrowserRouter(
  [
    {
      path: "/",
      element: <AppLayout />,
      children: [
        {
          path: "",
          element: <LandingPage />,
        },
        {
          path: "about",
          element: <AboutPage />,
        },
        {
          path: "product",
          element: <ProductPage />,
        },
        {
          path: "contact",
          element: <ContactPage />,
        },
      ],
    },

    {
      path: "*",
      element: <NoMatch />,
    },
  ],
  {
    basename: global.basename,
  }
);
